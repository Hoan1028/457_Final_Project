import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staffing',
  templateUrl: './staffing.page.html',
  styleUrls: ['./staffing.page.scss'],
})
export class StaffingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
