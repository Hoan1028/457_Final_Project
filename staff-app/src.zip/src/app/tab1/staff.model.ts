export class Staff {
    constructor(
        public id: string,
        public name: string,
        public job: string,
        public desc: string,
        public image: string,
        public salary: number
    ) {}
}
